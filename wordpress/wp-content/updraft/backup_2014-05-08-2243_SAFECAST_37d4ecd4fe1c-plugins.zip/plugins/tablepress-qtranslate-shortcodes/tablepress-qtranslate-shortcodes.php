<?php
/*
Plugin Name: TablePress Extension: qTranslate Shortcodes
Plugin URI: http://tablepress.org/extensions/qtranslate-shortcodes/
Description: Custom Extension for TablePress to enable qTranslate Shortcodes in table cells
Version: 1.1
Author: Tobias Bäthge
Author URI: http://tobias.baethge.com/
*/

add_action( 'tablepress_run', 'tablepress_qtranslate_shortcodes' );

function tablepress_qtranslate_shortcodes() {
	if ( ! function_exists( 'qtrans_useCurrentLanguageIfNotFoundUseDefaultLanguage' ) )
		return;

	add_filter( 'tablepress_cell_content', 'qtrans_useCurrentLanguageIfNotFoundUseDefaultLanguage' );
	add_filter( 'tablepress_table_render_data', 'tablepress_qtranslate_table_name_description', 10, 3 );
	add_filter( 'tablepress_table_render_options', 'tablepress_deactivate_table_output_caching', 10, 2 );
}

/*
 * Deactivate Table Output caching, as qTranslate Shortcodes will not work reliably otherwise
 */
function tablepress_deactivate_table_output_caching( $render_options, $table ) {
	$render_options['cache_table_output'] = false;
	return $render_options;
}

/*
 * Run the qTranslate Shortcodes in the table name and description
 */
function tablepress_qtranslate_table_name_description( $table, $orig_table, $render_options ) {
	$table['name'] = qtrans_useCurrentLanguageIfNotFoundUseDefaultLanguage( $table['name'] );
	$table['description'] = qtrans_useCurrentLanguageIfNotFoundUseDefaultLanguage( $table['description'] );
	return $table;
}
