<?php
	/// BLOG TEMPLATE
	get_template_part( 'template', 'blog' ); 
?>
