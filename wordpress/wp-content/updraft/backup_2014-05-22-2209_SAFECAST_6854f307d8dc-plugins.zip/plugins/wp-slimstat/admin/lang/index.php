<?php
// Silence is gold.