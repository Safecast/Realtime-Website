<?php get_header(); ?>

	<?php get_template_part( 'works', 'single' ); ?>

<?php get_footer(); ?>
