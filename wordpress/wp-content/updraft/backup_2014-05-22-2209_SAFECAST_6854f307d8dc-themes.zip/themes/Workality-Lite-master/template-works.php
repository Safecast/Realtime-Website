<?php
/*
Template Name: Works
*/
?>
<?php get_header(); ?>

	<?php get_template_part( 'works', 'index' ); ?>

<?php get_footer(); ?>
