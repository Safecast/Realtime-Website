<?php
/*
Template Name: Fullwidth Template
*/
?>

<?php get_template_part('templates/content', 'page'); ?>
