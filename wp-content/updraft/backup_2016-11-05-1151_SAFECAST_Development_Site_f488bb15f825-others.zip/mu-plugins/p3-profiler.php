<?php // Start profiling
@include_once( WP_PLUGIN_DIR . '/p3-profiler/start-profile.php' ); ?>