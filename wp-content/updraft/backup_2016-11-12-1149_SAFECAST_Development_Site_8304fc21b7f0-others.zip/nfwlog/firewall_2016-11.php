<?php exit; ?>
[1478525465] [0] [dev.rt.safecast.org] [#7087084] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478529310] [0] [dev.rt.safecast.org] [#2791501] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478529316] [0] [dev.rt.safecast.org] [#8501601] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478530924] [0] [dev.rt.safecast.org] [#7109879] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478531021] [0] [dev.rt.safecast.org] [#2885930] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478531025] [0] [dev.rt.safecast.org] [#7801963] [0] [6] [210.142.99.18] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478833518] [0] [dev.rt.safecast.org] [#5300220] [0] [6] [27.85.207.206] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
[1478945204] [0] [dev.rt.safecast.org] [#5653011] [0] [6] [27.93.163.127] [403] [GET] [/wp-admin/plugins.php] [Plugin deactivated by robouden] [hex:4e616d65203a206163662d717472616e736c6174652f6163662d717472616e736c6174652e706870]
