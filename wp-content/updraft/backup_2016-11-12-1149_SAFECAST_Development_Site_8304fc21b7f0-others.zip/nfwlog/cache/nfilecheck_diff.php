<?php die("Forbidden"); ?>
/var/www/dev.rt.safecast.org/wp-content/updraft/log.78f84b8c7703.txt::N::0644:33:33:37650:1478864944:1478864944
/var/www/dev.rt.safecast.org/wp-content/updraft/backup_2016-11-11-1149_SAFECAST_Development_Site_78f84b8c7703-db.gz::N::0644:33:33:856954:1478864944:1478864944
/var/www/dev.rt.safecast.org/wp-content/uploads/devices.json::M::0644:33:33:11564:1478785098:1478785098::0644:33:33:11546:1478871503:1478871503
/var/www/dev.rt.safecast.org/cli/updateSensorsMeasurements.php::M::0644:33:33:5405:1478606146:1478606146::0644:33:33:5678:1478857306:1478857306
/var/www/dev.rt.safecast.org/wp-content/updraft/backup_2016-11-03-1149_SAFECAST_Development_Site_517a2abe6ff8-db.gz::D::0644:33:33:834764:1478173743:1478173743
/var/www/dev.rt.safecast.org/wp-content/updraft/log.517a2abe6ff8.txt::D::0644:33:33:37390:1478173744:1478173744
