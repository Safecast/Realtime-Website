<footer class="content-info" role="contentinfo">
  <div class="container">
    <?php dynamic_sidebar('sidebar-footer'); ?>
    <p>This website by <a href="http://safecast.org" target="_blank">Safecast</a> is licensed under a <a href="http://creativecommons.org/licenses/by/4.0/deed.en_US" target="_blank" rel="nofollow">CC-By 4.0 License</a>.</p>
	<p>To the extent possible under law, <a href="http://safecast.org" target="_blank">Safecast</a> has <a href="https://creativecommons.org/publicdomain/zero/1.0/" target="_blank" rel="nofollow">waived all copyright and related or neighboring rights</a> to Safecast Data.</p>
  </div>
</footer>

<?php wp_footer(); ?>
