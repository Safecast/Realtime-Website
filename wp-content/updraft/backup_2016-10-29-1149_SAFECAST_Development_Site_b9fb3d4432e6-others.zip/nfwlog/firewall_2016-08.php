<?php exit; ?>
[1470993136] [0.00619] [dev.rt.safecast.org] [#2823229] [306] [1] [31.184.238.200] [403] [GET] [/index.php] [Bogus user-agent signature] [SERVER:HTTP_USER_AGENT = Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)]
[1471333543] [0.15848] [dev.rt.safecast.org] [#8137211] [306] [1] [27.153.206.72] [403] [GET] [/index.php] [Bogus user-agent signature] [SERVER:HTTP_USER_AGENT = Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)]
[1471340384] [0.80439] [dev.rt.safecast.org] [#8691883] [306] [1] [27.153.206.72] [403] [GET] [/index.php] [Bogus user-agent signature] [SERVER:HTTP_USER_AGENT = Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 2.0.50727)]
[1471822957] [0] [dev.rt.safecast.org] [#4758281] [0] [6] [49.239.77.43] [403] [POST] [/wp-login.php] [Logged in user] [robouden (administrator)]
[1471823052] [0] [dev.rt.safecast.org] [#2715802] [0] [6] [49.239.77.43] [403] [POST] [/wp-admin/update-core.php] [WordPress upgraded by robouden] [Version : 4.6]
[1471836056] [0.01565] [dev.rt.safecast.org] [#0000000] [0] [6] [71.89.228.89] [200] [POST] [/wp-comments-post.php] [Access to a script modified/created less than 10 hour(s) ago] [/var/www/dev.rt.safecast.org/wp-comments-post.php]
