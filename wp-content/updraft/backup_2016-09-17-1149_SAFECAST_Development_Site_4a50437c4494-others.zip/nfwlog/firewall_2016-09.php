<?php exit; ?>
[1473639210] [0] [dev.rt.safecast.org] [#1665662] [0] [6] [210.149.255.81] [403] [POST] [/wp-login.php] [Logged in user] [robouden (administrator)]
[1473639244] [0] [dev.rt.safecast.org] [#7173941] [0] [6] [210.142.98.252] [403] [POST] [/wp-admin/update-core.php] [WordPress upgraded by robouden] [Version : 4.6.1]
