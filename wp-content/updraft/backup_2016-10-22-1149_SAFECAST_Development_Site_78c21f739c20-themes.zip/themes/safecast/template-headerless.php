<?php
/*
Template Name: Headerless Template
*/
?>

<?php get_template_part('templates/content', 'page'); ?>
