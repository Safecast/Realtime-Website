<?php exit; ?>
[1475677298] [0] [dev.rt.safecast.org] [#1654136] [0] [6] [210.142.99.78] [403] [POST] [/wp-login.php] [Logged in user] [hex:726f626f7564656e202861646d696e6973747261746f7229]
