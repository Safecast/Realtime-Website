<?php exit; ?>
[1466482627] [0.00182] [dev.rt.safecast.org] [#3538022] [0] [5] [46.119.112.23] [403] [POST] [/wp-admin/admin-ajax.php] [Allowing file upload] [revslider.zip, 191,524 bytes]
[1466482627] [0.0106] [dev.rt.safecast.org] [#1461240] [1383] [3] [46.119.112.23] [403] [POST] [/wp-admin/admin-ajax.php] [WP: Revolution Slider/Showbiz shell upload] [REQUEST:client_action = update_plugin]
[1466482628] [0.01652] [dev.rt.safecast.org] [#8738141] [1369] [3] [46.119.112.23] [403] [POST] [/index.php] [WP: Download Manager remote command execution] [POST:execute = wp_insert_user]
[1466507836] [0] [dev.rt.safecast.org] [#1629261] [0] [6] [27.93.161.124] [403] [POST] [/wp-login.php] [Logged in user] [robouden (administrator)]
[1466654226] [0.01692] [dev.rt.safecast.org] [#4958128] [306] [1] [202.168.86.246] [403] [GET] [/index.php] [Bogus user-agent signature] [SERVER:HTTP_USER_AGENT = Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)]
